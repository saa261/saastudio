<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<label>NAMA APOTEK
		<h2>Apotek Annisa</h2>
	</label>

	<label>ALAMAT
		<h2>jln.Jendral Sudirman No.32 Padang, Sumatera Barat</h2>
	</label>

	<label>TAHUN AKTIF
		<h2>2015 s/d Sekarang</h2>
	</label>

	<label>JADWAL BUKA
		<h2>Setiap jam kerja, kecuali tanggal merah</h2>
	</label>
</body>
</html>