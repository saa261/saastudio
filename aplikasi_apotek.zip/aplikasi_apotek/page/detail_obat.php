<h3>Detail Obat</h3>

<?php
	$kdbarang=mysqli_real_escape_string($koneksi,@$_GET['kdbarang']);
	$barang=mysqli_query($koneksi, "SELECT * FROM barang a LEFT JOIN kategori_barang b ON a.kdkategori=b.kdkategori WHERE a.kdbarang='$kdbarang'");
	$cekdata=mysqli_num_rows($barang);
		if($cekdata==0){
				echo "<h3 style='color:red'>Maaf!! Data yang anda cari tidak ditemukan</h3>";
			}
	$tampildata=mysqli_fetch_array($barang);
?>
<div class="row">
	<div class="col-6">
		<img src="resources/image/produk/<?php echo $tampildata['gambar']; ?> "width="100%">
	</div>
	<div class="col-6">
		<div class="row">
			<label class="col-4">Nama Barang</label>
			<div class="produk_judul col-8"><?php echo $tampildata['nama_barang']; ?></div>
			</div>
		<div class="row">
			<label class="col-4">Deskripsi Barang</label>
			<div class="col-8"><?php echo $tampildata['deskripsi_barang']; ?>....</div>
			</div> 
		<div class="row">
			<label class="col-4">Kategori Barang</label>
			<div class="col-8"><?php echo $tampildata['nama_kategori']; ?>	
			</div>
		</div>
		<div class="row">
		<label class="col-4">Tanggal Expired</label>		
			<div class="col-8"><?php echo $tampildata['tanggal_expired']; ?></div>
			</div>
		<div class="row">
			<label class="col-4">Kode Barcode</label>
			<div class="col-8"><?php echo $tampildata['barcode']; ?></div>
			</div>
		<div class="row">
			<label class="col-4">Harga User</label>
			<div class="produk_harga col-8">Rp.<?php echo number_format ($tampildata['harga_user'],0);?></div>
		</div>
	</div>
</div>


<a href="./">KEMBALI</a> 