<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<h1>Bukti Transaksi bisa diambil di Loket Pembayaran Obat</h1>
</body>
</html>