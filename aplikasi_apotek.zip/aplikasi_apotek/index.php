<?php
include "koneksi.php";
?>
<!DOCTYPE html>
<html>
<head>
	<title>Aplikasi Apotek Annisa</title>
	<link rel="stylesheet" type="text/css" href="resources/css/style.css">
</head>
<body>

	<section class="header">
		<div class="container">
			<div class="row">
				<div class="col-4">
					<div class="header_title">APOTEK ANNISA</div>
					</div>
				</div>
				<div class="col-8">
					<form action="?page=pencarian_obat" method="post">
						<input type="text" name="nama_barang" placeholder="Pencarian Data Obat...." class="header_pencarian_obat">
						<input type="Submit" name="Cari" value="Cari" class="header_pencarian_button">
					</form>
				</div>
			</div>
		</div>
	</section>
	<section class="menu_atas">
		<div class="container">
		<a href="./" class="menu_atas_link">Beranda</a>
		<a href="?page=informasi" class="menu_atas_link">Informasi Apotek</a>
		<a href="?page=transaksi" class="menu_atas_link">Transaksi</a>
		<a href="?page=kontak" class="menu_atas_link">Call Center</a>
		</div>
	</section>

	<div class="konten">
		<div class="container">
			<div class="konten_data">
				<?php
					$page=mysqli_real_escape_string($koneksi,@$_GET['page']);
					if($page=="home"){
						include"page/home.php";
					}elseif ($page=="detail_obat") {
						include"page/detail_obat.php";
					}elseif ($page=="pencarian_obat") {
						include"page/pencarian_obat.php";
					}elseif ($page=="informasi") {
						include"page/informasi.php";
					}elseif ($page=="transaksi") {
						include"page/transaksi.php";
					}elseif ($page=="kontak") {
						include"page/kontak.php";
					}else{
						include"page/home.php";
					}
				?>
			</div>
		</div>
	</div>

</body>
</html>