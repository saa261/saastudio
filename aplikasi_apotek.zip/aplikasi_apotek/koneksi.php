<?php
$koneksi=mysqli_connect("localhost","root","","aplikasi_apotek") or die("Maaf koneksi ke database gagal");
?>